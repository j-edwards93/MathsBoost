package com.Unit7.MobileApps.MathsBoost.Utils;

public class Constants {

    public static String MYPREF = "pref";
    public static String MYPREF1 = "pref1";
    public static String OPERATION_TYPE = "value";
    public static String SOUND = "sound";
    public static String TYPE = "type";
    public static String SECOND_TIME = "second";
    public static String SCORE = "score";
    public static String TRUEQUESTION = "true_ques";
    public static String WRONGQUESTION = "worng_ques";
    public static String TITLE = "title";
}
