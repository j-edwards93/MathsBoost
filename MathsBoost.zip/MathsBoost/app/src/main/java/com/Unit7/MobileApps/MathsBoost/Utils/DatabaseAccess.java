package com.Unit7.MobileApps.MathsBoost.Utils;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseAccess {
    private static DatabaseAccess instance;
    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase database;

    private DatabaseAccess(Context context) {
        this.openHelper = new DatabaseOpenHelper(context);
    }

    public static DatabaseAccess getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseAccess(context);
        }
        return instance;
    }

    public void open() {
        this.database = openHelper.getWritableDatabase();
    }

    public void close() {
        if (database != null) {
            this.database.close();
        }
    }


    public List<Model> getRandomData(String tablename,String type) {
        Cursor cur = database.rawQuery("select * from " + tablename + " where type = '"+type+"'  GROUP BY id ORDER BY Random() limit 15", null);
        List<Model> item_data = new ArrayList<>();
        if (cur.getCount() != 0) {
            if (cur.moveToFirst()) {
                do {
                    Model obj = new Model();

                    obj.id = cur.getString(cur.getColumnIndex("id"));
                    obj.number1 = cur.getString(cur.getColumnIndex("number1"));
                    obj.number2 = cur.getString(cur.getColumnIndex("number2"));
                    obj.op1 = cur.getString(cur.getColumnIndex("op1"));
                    obj.op2 = cur.getString(cur.getColumnIndex("op2"));
                    obj.op3 = cur.getString(cur.getColumnIndex("op3"));
                    obj.op4 = cur.getString(cur.getColumnIndex("op4"));
                    obj.sign = cur.getString(cur.getColumnIndex("sign"));
                    obj.answer = cur.getString(cur.getColumnIndex("answer"));

                    item_data.add(obj);
                } while (cur.moveToNext());
            }
        }
        cur.close();
        return item_data;
    }
//
//
//    public List<Model> getRandomData1(String tablename) {
//        Cursor cur = database.rawQuery("select * from " + tablename + "", null);
//        List<Model> item_data = new ArrayList<>();
//        if (cur.getCount() != 0) {
//            if (cur.moveToFirst()) {
//                do {
//                    Model obj = new Model();
//
//                    obj.id = cur.getString(cur.getColumnIndex("id"));
//                    obj.number1 = cur.getString(cur.getColumnIndex("number1"));
//                    obj.sign = cur.getString(cur.getColumnIndex("sign"));
//                    obj.number2 = cur.getString(cur.getColumnIndex("number2"));
//                    obj.option1 = cur.getString(cur.getColumnIndex("op_1"));
//                    obj.option2 = cur.getString(cur.getColumnIndex("op_2"));
//                    obj.option3 = cur.getString(cur.getColumnIndex("op_3"));
//                    obj.option4 = cur.getString(cur.getColumnIndex("op_4"));
//
//                    obj.answer = cur.getString(cur.getColumnIndex("answer"));
//                    obj.ref_id = cur.getString(cur.getColumnIndex("ref_id"));
//
//                    item_data.add(obj);
//                } while (cur.moveToNext());
//            }
//        }
//        cur.close();
//        return item_data;
//    }


//    public List<Model> getRandomAddData(String tablename, int ref_id) {
//        Cursor cur = database.rawQuery("select * from " + tablename + " where ref_id= " + ref_id + " GROUP BY id ORDER BY Random() LIMIT 10", null);
//        List<Model> item_data = new ArrayList<>();
//        if (cur.getCount() != 0) {
//            if (cur.moveToFirst()) {
//                do {
//                    Model obj = new Model();
//
//                    obj.id = cur.getString(cur.getColumnIndex("id"));
//                    obj.question = cur.getString(cur.getColumnIndex("ques"));
//                    obj.option1 = cur.getString(cur.getColumnIndex("op_1"));
//                    obj.option2 = cur.getString(cur.getColumnIndex("op_2"));
//                    obj.option3 = cur.getString(cur.getColumnIndex("op_3"));
//                    obj.option4 = cur.getString(cur.getColumnIndex("op_4"));
//                    obj.answer = cur.getString(cur.getColumnIndex("answer"));
//                    obj.ref_id = cur.getString(cur.getColumnIndex("ref_id"));
//
//                    item_data.add(obj);
//                } while (cur.moveToNext());
//            }
//        }
//        cur.close();
//        return item_data;
//    }


//    public List<Model> getRandomData(int ref_id) {
//        Cursor cur = database.rawQuery("select * from addition_table where ref_id= "+ref_id+" GROUP BY id ORDER BY Random() LIMIT 10", null);
//        List<Model> item_data = new ArrayList<>();
//        if (cur.getCount() != 0) {
//            if (cur.moveToFirst()) {
//                do {
//                    Model obj = new Model();
//
//                    obj.id = cur.getString(cur.getColumnIndex("id"));
//                    obj.question = cur.getString(cur.getColumnIndex("ques"));
//                    obj.option1 = cur.getString(cur.getColumnIndex("op_1"));
//                    obj.option2 = cur.getString(cur.getColumnIndex("op_2"));
//                    obj.option3 = cur.getString(cur.getColumnIndex("op_3"));
//                    obj.option4 = cur.getString(cur.getColumnIndex("op_4"));
//                    obj.answer = cur.getString(cur.getColumnIndex("answer"));
//                    obj.ref_id = cur.getString(cur.getColumnIndex("ref_id"));
//
//                    item_data.add(obj);
//                } while (cur.moveToNext());
//            }
//        }
//        cur.close();
//        return item_data;
//    }


}
